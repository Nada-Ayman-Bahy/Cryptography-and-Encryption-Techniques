package Milestone_2;

import java.util.Scanner;

public class AtbashCipher {

    // Method to encrypt the plaintext using the Atbash cipher
    public static String encrypt(String plaintext) {
        StringBuilder ciphertext = new StringBuilder();
        plaintext = plaintext.toUpperCase(); // Convert to uppercase for simplicity

        // Loop through each character in the plaintext
        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);
            
            // Check if the character is an alphabet
            if (ch >= 'A' && ch <= 'Z') {
                // Reverse the character using the Atbash cipher formula
                ch = (char) ('A' + ('Z' - ch));
            }
            ciphertext.append(ch);
        }
        return ciphertext.toString();
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Plaintext to be encrypted
        System.out.print("Enter the plaintext: ");
        String plaintext = scanner.nextLine();

        // Encrypt the plaintext
        String ciphertext = encrypt(plaintext);

        // Output the ciphertext
        System.out.println("Encrypted Text: " + ciphertext);

    }
}
