package Milestone_2;
import java.util.Scanner;

public class VigenereCipher {

    // Method to encrypt the plaintext using Vigenere Cipher
    public static String encrypt(String text, String keyword) {
        StringBuilder result = new StringBuilder();
        text = text.toUpperCase();
        keyword = keyword.toUpperCase();
        
        for (int i = 0, j = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            
            // Only encrypt alphabetic characters
            if (c >= 'A' && c <= 'Z') {
                result.append((char) ((c + keyword.charAt(j) - 2 * 'A') % 26 + 'A'));
                j = ++j % keyword.length();
            } else {
                result.append(c); // Non-alphabet characters are added as-is
            }
        }
        
        return result.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input keyword and plaintext from the user
        System.out.print("Enter keyword: ");
        String keyword = scanner.nextLine();

        System.out.print("Enter plaintext: ");
        String plaintext = scanner.nextLine();

        // Encrypt and display the ciphertext
        String ciphertext = encrypt(plaintext, keyword);
        System.out.println("Ciphertext: " + ciphertext);

        scanner.close();
    }
}