package Milestone_2;
import java.util.ArrayList;
import java.util.Scanner;

public class PlayfairCipher {

    private char[][] keyMatrix = new char[5][5];
    private String keyword;

    public PlayfairCipher(String keyword) {
        this.keyword = prepareKeyword(keyword);
        generateKeyMatrix();
    }

    // Prepares the keyword by removing duplicates and merging 'I' and 'J'
    private String prepareKeyword(String keyword) {
        StringBuilder sb = new StringBuilder();
        keyword = keyword.toUpperCase().replace("J", "I");
        for (char c : keyword.toCharArray()) {
            if (sb.indexOf(String.valueOf(c)) == -1 && Character.isLetter(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // Generates the 5x5 key matrix using the keyword
    private void generateKeyMatrix() {
        StringBuilder sb = new StringBuilder(keyword);
        for (char c = 'A'; c <= 'Z'; c++) {
            if (c != 'J' && sb.indexOf(String.valueOf(c)) == -1) {
                sb.append(c);
            }
        }
        int index = 0;
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                keyMatrix[row][col] = sb.charAt(index++);
            }
        }
    }

    // Encrypts the given plaintext using the Playfair Cipher rules
    public String encrypt(String plaintext) {
        ArrayList<String> digraphs = prepareDigraphs(plaintext);
        StringBuilder ciphertext = new StringBuilder();

        for (String digraph : digraphs) {
            char first = digraph.charAt(0);
            char second = digraph.charAt(1);
            int[] posFirst = getPosition(first);
            int[] posSecond = getPosition(second);

            // Rule 1: Same Row
            if (posFirst[0] == posSecond[0]) {
                ciphertext.append(keyMatrix[posFirst[0]][(posFirst[1] + 1) % 5]);
                ciphertext.append(keyMatrix[posSecond[0]][(posSecond[1] + 1) % 5]);
            }
            // Rule 2: Same Column
            else if (posFirst[1] == posSecond[1]) {
                ciphertext.append(keyMatrix[(posFirst[0] + 1) % 5][posFirst[1]]);
                ciphertext.append(keyMatrix[(posSecond[0] + 1) % 5][posSecond[1]]);
            }
            // Rule 3: Rectangle (Modified)
            else {
                // Order by row: take the letter from the row of the first character, column of the second,
                // then the letter from the row of the second character, column of the first.
                ciphertext.append(keyMatrix[posFirst[0]][posSecond[1]]);
                ciphertext.append(keyMatrix[posSecond[0]][posFirst[1]]);
            }
        }
        return ciphertext.toString();
    }

    // Prepares digraphs from plaintext, adding 'Z' if length is odd or duplicates are found
    private ArrayList<String> prepareDigraphs(String plaintext) {
        StringBuilder sb = new StringBuilder(plaintext.toUpperCase().replaceAll("[^A-Z]", "").replace("J", "I"));
        ArrayList<String> digraphs = new ArrayList<>();

        for (int i = 0; i < sb.length(); i += 2) {
            if (i == sb.length() - 1) {
                sb.append('Z'); // If last character has no pair, add 'Z'
            }
            if (sb.charAt(i) == sb.charAt(i + 1)) {
                sb.insert(i + 1, 'X'); // Insert 'X' if there are duplicate letters in a digraph
            }
            digraphs.add(sb.substring(i, i + 2));
        }

        return digraphs;
    }

    // Finds the position of a character in the key matrix
    private int[] getPosition(char c) {
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (keyMatrix[row][col] == c) {
                    return new int[]{row, col};
                }
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input keyword and plaintext from the user
        System.out.print("Enter keyword: ");
        String keyword = scanner.nextLine();
        PlayfairCipher playfair = new PlayfairCipher(keyword);

        System.out.print("Enter plaintext: ");
        String plaintext = scanner.nextLine();

        // Encrypt and display the ciphertext
        String ciphertext = playfair.encrypt(plaintext);
        System.out.println("Ciphertext: " + ciphertext);

        scanner.close();
    }
}
